#import pygame

imgRes={"mrBlueBody":"./res/mrBlue.png",
        "mrRedBody":"./res/mrRed.png",
        "dice1Dot":"./res/one.png",
        "dice2Dot":"./res/two.png",
        "dice3Dot":"./res/three.png",
        "dice4Dot":"./res/four.png",
        "dice5Dot":"./res/five.png",
        "dice6Dot":"./res/six.png",       
        "savebtn":"./res/SaveButton.png"
    }
weponType={"Dagger":2,
        "Sward":5,
        "Pistol":8,
        "Rifle":15,
        "Sniper":20,
        "ShotGun":25
    }
weponsList=["Dagger","Sward","Pistol","Rifle","Sniper","ShotGun"]    