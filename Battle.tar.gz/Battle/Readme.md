# Battle Mr.Red Vs Mr Blue



## Installation

```bash
$ tar -xvf Battle.tar.gz
$ cd Battle/
$ pip install -r requirements.txt
```

## How To Run

### if player wants to input number of chances manually
```bash
$ python playBattle.py
```
### if player wants to load number of chances from config file

```bash
$ python playBattle.py auto
```
## Controls
### if player wants to input number of chances manualy, 
### type number of chances when input box appears
### and press "Enter Key"

### To start game once game is displayed on screen click anywhere on the screen

### To Quit the game at any point of time press "Esc"

### To save the output to output file:
### once game is over, click on the save button appearing on the screen
